<?php
return array(
	'_update_adv_success_' 		=> '设置广告成功',
	'_update__adv_error_' 		=> '设置广告失败',
	'_del_adv_success_' 		=> '删除广告成功' ,
	'_status_success_' 			=> '改变状态成功' ,
	'_status_error_' 			=> '改变状态失败' ,
	'_del_adv_position_success_' => '删除广告位成功' ,
	'_update_adv_position_success_' => '更新广告位成功' ,
	'_no_advposition_'			=>'请先添加广告位',
	'no_delete_advposition_'	=>'请先清空广告',

	'adv_require'				=> '广告位名称不能为空',
	'adv_name_require'			=> '广告名称不能为空',
	'adv_position_require'		=> '广告位不能为空',
	'endtime_not_gt_atarttime'	=> '结束日期不能大于开始日期',
);