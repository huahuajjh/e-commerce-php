<?php
return array(
	'site_isclosed' => 'hook',
	'global_footer' => 'hook'
);