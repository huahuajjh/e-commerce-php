<?php
/* 更新商品分类缓存 */
model('goods/goods_category','service')->build_cache();