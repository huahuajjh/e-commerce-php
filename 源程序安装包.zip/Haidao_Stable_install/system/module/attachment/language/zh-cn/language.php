<?php
return array(
    'upload_success' 		=> '上传成功',
    'delete_not_exist' 		=> '请指定要删除的图片',
    'delete_success' 		=> '图片删除成功',
    'no_promission_upload'	=> '没有上传权限',
    'file_upload_empty'		=> '没有上传任何文件',
    'catalog_empty'			=> '目录不能为空',
);
