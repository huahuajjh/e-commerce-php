<?php
return array(
	'validate_username_tooshort' => '用户名长度太短',
	'validate_username_toolong'	=> '用户名长度太长',
	'validate_username_exists'	=> '该用户已存在',

	'password_weak' => '密码太弱，密码中必须包含',
	'strongpw_1' => '数字',
	'strongpw_2' => '小写字母',
	'strongpw_3' => '大写字母',
	'strongpw_4' => '特殊符号',

	'profile_password_tooshort' => '密码不能少于 {pwlength} 位',
	'password_confirm'	=> '两次密码输入不一致',
);