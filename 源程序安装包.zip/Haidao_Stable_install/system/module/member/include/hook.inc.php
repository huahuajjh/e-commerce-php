<?php
return array(
	'pay_success' => 'hook',
	'email_validate' => 'hook',
	'register_validate' => 'hook',
	'mobile_validate'  => 'hook',
	'money_change'  => 'hook',
	'forget_pwd'  => 'hook',
	'member_init'  =>  'hook',
	'after_login' => 'hook',
);