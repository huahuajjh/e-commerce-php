<?php
return array(
	'html_load'  => 'hook',
	'after_register' => 'hook'
);