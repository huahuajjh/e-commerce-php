<?php
return array(
    'upload_message_success' 	=> '更新通知模板完成',
    'no_found_config_file' 		=> '没有找到驱动配置文件',
    'config_operate_error' 		=> '配置操作失败',
    'uninstall_success' 		=> '卸载成功',
);
