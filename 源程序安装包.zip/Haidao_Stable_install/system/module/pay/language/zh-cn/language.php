<?php
return array(
    '_enabled_success_' 	=> '设置支付方式成功',
    '_enabled_error_' 		=> '设置支付方式失败',
    '_uninstall_success_' 	=> '卸载支付方式成功',
    '_uninstall_error_' 	=> '卸载支付方式失败',
    'order_pay_success' 	=> '订单支付成功',
    'no_promission_view' 	=> '抱歉，您无法查看此订单',
    'order_paid' 			=> '该订单已支付',
    'pay_set_error' 		=> '支付请求创建失败',
    'pay_code_require'		=> '支付方式不存在',
    'pay_name_require'		=> '支付名称必须存在',
    'config_require'		=> '支付配置必须存在',
);
