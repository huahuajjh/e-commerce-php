<?php
return array(
	'update_cache' => 'hook',
	'global_footer' => 'hook'
);