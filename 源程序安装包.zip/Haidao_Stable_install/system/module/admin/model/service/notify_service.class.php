<?php 
class notify_service extends service
{
	
}