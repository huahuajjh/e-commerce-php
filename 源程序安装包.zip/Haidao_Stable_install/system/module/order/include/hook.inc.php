<?php
return array(
	'create_order'  =>  'hook',
	'pay_success'  => 'hook',
	'confirm_order'  =>  'hook',
	'skus_delivery'  =>  'hook',
	'delivery_finish'  => 'hook',
	'order_finish'  => 'hook',
	'after_login' => 'hook',
	'after_register' => 'hook'
);