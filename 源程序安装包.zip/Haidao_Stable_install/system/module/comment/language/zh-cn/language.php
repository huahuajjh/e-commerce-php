<?php
return array(
    'reply_success'                 => '回复成功',
    'estimate_delete_success'       => '评价删除成功',
    'publish_estimate_success'      => '发表评价成功',
    'repeat_publish'                => '请勿重复发表',
    'member_info_error'             => '会员信息异常',
    'goods_info_error' 	            => '商品信息异常',
    'evaluate_info_error'           => '评价信息异常',
    'evaluate_content_empty'        => '评价内容不能为空',
    'evaluate_empty'                => '评价不存在',
);
