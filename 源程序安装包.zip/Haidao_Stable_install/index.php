<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
define('CHARSET', 'utf-8');
define('DOC_ROOT', str_replace("\\", '/', dirname(__FILE__) ).'/');
define('APP_PATH', DOC_ROOT.'system/');
define('APP_DEBUG', false);
include APP_PATH.'base.php';