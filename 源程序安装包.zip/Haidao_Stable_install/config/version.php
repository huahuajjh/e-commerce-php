<?php
if(!defined('HD_VERSION')) {
	define('HD_VERSION', '2.0.3.161021');
	define('HD_RELEASE', '20161021');
	define('HD_BRANCH', 'stable');
	define('HD_FIXBUG', '00000003');
}