var category = (function() {
	return {
		popup : function() {
			
		}
	}
})();